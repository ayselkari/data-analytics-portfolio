# Travel & Tourism Data Analytics Portfolio

Three personal portfolio projects focused on travel operations and tourism data.

## Projects

### 1. Travel Sales Dashboard — Excel
Tools: Excel formulas, summaries, charts and dashboard design.
Business questions: revenue by destination, monthly performance, profit and cancellations.

### 2. Hotel Booking Analysis — SQL
Tools: SQL aggregation, CASE statements, grouping and business KPIs.
Business questions: cancellation behaviour, revenue by country, ADR by room type and lead-time patterns.

### 3. Tourism Performance Dashboard — Power BI
Tools: Power BI, DAX measures and interactive dashboard design.
Business questions: revenue, profit, bookings, customer segments, destinations and booking channels.

## Data
All datasets are synthetic and created specifically for portfolio practice. They do not represent confidential employer data.

## Positioning
These are personal projects demonstrating practical data-analysis skills in a tourism/travel context.